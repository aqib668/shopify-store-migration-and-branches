import { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { insertStoreSchema, insertMigrationSchema } from "@shared/schema";
import { createShopifyClient } from "./lib/shopify";
import { Shopify } from '@shopify/shopify-api';

const { SHOPIFY_API_KEY, SHOPIFY_API_SECRET } = process.env;

if (!SHOPIFY_API_KEY || !SHOPIFY_API_SECRET) {
  throw new Error('Missing Shopify API credentials');
}

export function registerRoutes(app: Express) {
  // Shopify Auth routes
  app.post("/api/auth", async (req, res) => {
    try {
      const { shop } = req.body;
      if (!shop) {
        return res.status(400).json({ message: "Shop parameter is required" });
      }

      const authUrl = `https://${shop}/admin/oauth/authorize?` +
        `client_id=${SHOPIFY_API_KEY}&` +
        `scope=read_products,write_products&` +
        `redirect_uri=${process.env.APP_URL}/install`;

      res.json({ authUrl });
    } catch (error) {
      console.error("Auth error:", error);
      res.status(500).json({ message: "Failed to start installation" });
    }
  });

  app.post("/api/auth/callback", async (req, res) => {
    try {
      const { shop, code } = req.body;

      // Exchange code for access token
      const accessTokenResponse = await fetch(
        `https://${shop}/admin/oauth/access_token`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            client_id: SHOPIFY_API_KEY,
            client_secret: SHOPIFY_API_SECRET,
            code,
          }),
        }
      );

      const { access_token } = await accessTokenResponse.json();

      // Store the shop details
      const store = await storage.createStore({
        name: shop.split('.')[0],
        domain: shop,
        accessToken: access_token,
      });

      res.json(store);
    } catch (error) {
      console.error("Auth callback error:", error);
      res.status(500).json({ message: "Failed to complete installation" });
    }
  });

  // Existing store management routes
  app.post("/api/stores", async (req, res) => {
    try {
      const data = insertStoreSchema.parse(req.body);
      const store = await storage.createStore(data);
      res.json(store);
    } catch (error) {
      res.status(400).json({ message: "Invalid store data" });
    }
  });

  app.get("/api/stores", async (req, res) => {
    const stores = await storage.listStores();
    res.json(stores);
  });

  // New branching and inventory routes
  app.post("/api/stores/:id/branches", async (req, res) => {
    try {
      const parentId = parseInt(req.params.id);
      const data = insertStoreSchema.parse({
        ...req.body,
        parentStoreId: parentId,
        isBranch: true,
      });
      const store = await storage.createStore(data);
      res.json(store);
    } catch (error) {
      res.status(400).json({ message: "Invalid branch store data" });
    }
  });

  app.get("/api/stores/:id/branches", async (req, res) => {
    try {
      const parentId = parseInt(req.params.id);
      const branches = await storage.getBranchStores(parentId);
      res.json(branches);
    } catch (error) {
      res.status(400).json({ message: "Failed to fetch branch stores" });
    }
  });

  app.post("/api/stores/:id/sync-inventory", async (req, res) => {
    try {
      const storeId = parseInt(req.params.id);
      const store = await storage.getStore(storeId);

      if (!store) {
        return res.status(404).json({ message: "Store not found" });
      }

      const client = createShopifyClient(store.domain, store.accessToken);
      const products = await client.getProducts();

      for (const edge of products.edges) {
        const product = edge.node;
        const variant = product.variants.edges[0]?.node;

        if (variant) {
          const [existingProduct] = await storage.getStoreProducts(storeId);
          if (existingProduct) {
            await storage.updateProductInventory(
              existingProduct.id,
              variant.inventoryQuantity
            );
          } else {
            await storage.createProduct({
              storeId,
              shopifyProductId: product.id,
              title: product.title,
              inventory: variant.inventoryQuantity,
              variantId: variant.id,
            });
          }
        }
      }

      res.json({ message: "Inventory sync completed" });
    } catch (error) {
      console.error("Sync error:", error);
      res.status(500).json({ message: "Failed to sync inventory" });
    }
  });

  // Existing migration routes
  app.post("/api/migrations", async (req, res) => {
    try {
      const data = insertMigrationSchema.parse(req.body);
      const migration = await storage.createMigration(data);
      res.json(migration);
    } catch (error) {
      res.status(400).json({ message: "Invalid migration data" });
    }
  });

  app.get("/api/migrations/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const migration = await storage.getMigration(id);
    if (!migration) {
      res.status(404).json({ message: "Migration not found" });
      return;
    }
    res.json(migration);
  });

  app.patch("/api/migrations/:id/status", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { status, progress, error } = req.body;
      const migration = await storage.updateMigrationStatus(id, status, progress, error);
      res.json(migration);
    } catch (error) {
      res.status(400).json({ message: "Failed to update migration status" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
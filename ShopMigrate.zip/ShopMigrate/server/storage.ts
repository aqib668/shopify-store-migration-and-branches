import { stores, products, migrations, type Store, type InsertStore, type Migration, type InsertMigration, type Product, type InsertProduct } from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  // Store operations
  getStore(id: number): Promise<Store | undefined>;
  createStore(store: InsertStore): Promise<Store>;
  listStores(): Promise<Store[]>;
  getBranchStores(parentStoreId: number): Promise<Store[]>;

  // Product operations
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProductInventory(id: number, inventory: number): Promise<Product>;
  getStoreProducts(storeId: number): Promise<Product[]>;

  // Migration operations
  getMigration(id: number): Promise<Migration | undefined>;
  createMigration(migration: InsertMigration): Promise<Migration>;
  updateMigrationStatus(id: number, status: string, progress?: number, error?: string): Promise<Migration>;
}

export class DatabaseStorage implements IStorage {
  async getStore(id: number): Promise<Store | undefined> {
    const [store] = await db.select().from(stores).where(eq(stores.id, id));
    return store;
  }

  async createStore(insertStore: InsertStore): Promise<Store> {
    const [store] = await db.insert(stores).values(insertStore).returning();
    return store;
  }

  async listStores(): Promise<Store[]> {
    return await db.select().from(stores);
  }

  async getBranchStores(parentStoreId: number): Promise<Store[]> {
    return await db
      .select()
      .from(stores)
      .where(and(
        eq(stores.parentStoreId, parentStoreId),
        eq(stores.isBranch, true)
      ));
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const [product] = await db.insert(products).values(insertProduct).returning();
    return product;
  }

  async updateProductInventory(id: number, inventory: number): Promise<Product> {
    const [product] = await db
      .update(products)
      .set({ inventory, lastSynced: new Date() })
      .where(eq(products.id, id))
      .returning();
    return product;
  }

  async getStoreProducts(storeId: number): Promise<Product[]> {
    return await db
      .select()
      .from(products)
      .where(eq(products.storeId, storeId));
  }

  async getMigration(id: number): Promise<Migration | undefined> {
    const [migration] = await db.select().from(migrations).where(eq(migrations.id, id));
    return migration;
  }

  async createMigration(insertMigration: InsertMigration): Promise<Migration> {
    const [migration] = await db
      .insert(migrations)
      .values({
        ...insertMigration,
        status: 'pending',
        progress: 0,
        productCount: 0,
        collectionCount: 0
      })
      .returning();
    return migration;
  }

  async updateMigrationStatus(
    id: number,
    status: string,
    progress?: number,
    error?: string
  ): Promise<Migration> {
    const [migration] = await db
      .update(migrations)
      .set({ status, progress, error })
      .where(eq(migrations.id, id))
      .returning();

    if (!migration) throw new Error("Migration not found");
    return migration;
  }
}

export const storage = new DatabaseStorage();
import { Shopify } from '@shopify/shopify-api';

export class ShopifyClient {
  private client: Shopify;
  private domain: string;
  private accessToken: string;

  constructor(domain: string, accessToken: string) {
    this.domain = domain;
    this.accessToken = accessToken;
  }

  async getProducts(limit = 50, pageInfo?: string) {
    const query = `
      query($limit: Int!, $cursor: String) {
        products(first: $limit, after: $cursor) {
          pageInfo {
            hasNextPage
            endCursor
          }
          edges {
            node {
              id
              title
              variants(first: 1) {
                edges {
                  node {
                    id
                    inventoryQuantity
                  }
                }
              }
            }
          }
        }
      }
    `;

    const response = await this.makeGraphQLRequest(query, {
      limit,
      cursor: pageInfo,
    });

    return response.products;
  }

  async updateInventory(variantId: string, quantity: number) {
    const mutation = `
      mutation inventoryAdjustQuantity($input: InventoryAdjustQuantityInput!) {
        inventoryAdjustQuantity(input: $input) {
          inventoryLevel {
            available
          }
          userErrors {
            field
            message
          }
        }
      }
    `;

    return await this.makeGraphQLRequest(mutation, {
      input: {
        inventoryItemId: variantId,
        availableDelta: quantity,
      },
    });
  }

  private async makeGraphQLRequest(query: string, variables: Record<string, any>) {
    const response = await fetch(`https://${this.domain}/admin/api/2024-01/graphql.json`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Shopify-Access-Token': this.accessToken,
      },
      body: JSON.stringify({
        query,
        variables,
      }),
    });

    if (!response.ok) {
      throw new Error(`Shopify API error: ${response.statusText}`);
    }

    const data = await response.json();
    if (data.errors) {
      throw new Error(`GraphQL Error: ${data.errors[0].message}`);
    }

    return data.data;
  }
}

export function createShopifyClient(domain: string, accessToken: string) {
  return new ShopifyClient(domain, accessToken);
}

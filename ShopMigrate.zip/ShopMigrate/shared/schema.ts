import { pgTable, text, serial, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const stores = pgTable("stores", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  domain: text("domain").notNull(),
  accessToken: text("access_token").notNull(),
  parentStoreId: integer("parent_store_id").references(() => stores.id),
  isBranch: boolean("is_branch").default(false),
  syncInventory: boolean("sync_inventory").default(false),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  storeId: integer("store_id").notNull().references(() => stores.id),
  shopifyProductId: text("shopify_product_id").notNull(),
  title: text("title").notNull(),
  inventory: integer("inventory").default(0),
  variantId: text("variant_id"),
  sourceProductId: integer("source_product_id").references(() => products.id),
  lastSynced: timestamp("last_synced"),
});

export const migrations = pgTable("migrations", {
  id: serial("id").primaryKey(),
  sourceStoreId: integer("source_store_id").notNull(),
  destStoreId: integer("dest_store_id").notNull(),
  status: text("status").notNull(), // pending, running, completed, failed
  progress: integer("progress").default(0),
  error: text("error"),
  productCount: integer("product_count").default(0),
  collectionCount: integer("collection_count").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertStoreSchema = createInsertSchema(stores).pick({
  name: true,
  domain: true,
  accessToken: true,
  parentStoreId: true,
  isBranch: true,
  syncInventory: true,
});

export const insertProductSchema = createInsertSchema(products).pick({
  storeId: true,
  shopifyProductId: true,
  title: true,
  inventory: true,
  variantId: true,
  sourceProductId: true,
});

export const insertMigrationSchema = createInsertSchema(migrations).pick({
  sourceStoreId: true,
  destStoreId: true,
});

export type InsertStore = z.infer<typeof insertStoreSchema>;
export type Store = typeof stores.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;
export type InsertMigration = z.infer<typeof insertMigrationSchema>;
export type Migration = typeof migrations.$inferSelect;
import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ArrowLeftRight, GitBranch, BarChart2, Settings } from "lucide-react";

const sidebarItems = [
  {
    title: "Migration",
    icon: ArrowLeftRight,
    href: "/",
  },
  {
    title: "Branch Stores",
    icon: GitBranch,
    href: "/branches",
  },
  {
    title: "Statistics",
    icon: BarChart2,
    href: "/stats",
  },
  {
    title: "Settings",
    icon: Settings,
    href: "/settings",
  },
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <div className="pb-12 w-64 bg-sidebar border-r">
      <div className="space-y-4 py-4">
        <div className="px-3 py-2">
          <h2 className="mb-2 px-4 text-lg font-semibold">
            Shopify Migration
          </h2>
          <div className="space-y-1">
            {sidebarItems.map((item) => (
              <Link key={item.href} href={item.href}>
                <Button
                  variant={location === item.href ? "secondary" : "ghost"}
                  className={cn(
                    "w-full justify-start",
                    location === item.href && "bg-sidebar-accent"
                  )}
                >
                  <item.icon className="mr-2 h-4 w-4" />
                  {item.title}
                </Button>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Store, Migration } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { ArrowLeftRight, Check, XCircle, GitBranch, RefreshCw } from "lucide-react";
import { Switch } from "@/components/ui/switch";

export default function Migrate() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [selectedSource, setSelectedSource] = useState<number>();
  const [selectedDest, setSelectedDest] = useState<number>();
  const [migrationId, setMigrationId] = useState<number>();
  const [selectedParentStore, setSelectedParentStore] = useState<number>();

  const { data: stores } = useQuery<Store[]>({
    queryKey: ["/api/stores"],
  });

  const { data: migration } = useQuery<Migration>({
    queryKey: ["/api/migrations", migrationId],
    enabled: !!migrationId,
    refetchInterval: (data) =>
      data?.status === "running" ? 1000 : false,
  });

  const { data: branchStores } = useQuery<Store[]>({
    queryKey: ["/api/stores", selectedParentStore, "branches"],
    enabled: !!selectedParentStore,
  });

  const createMigrationMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/migrations", {
        sourceStoreId: selectedSource,
        destStoreId: selectedDest,
      });
      const data = await res.json();
      setMigrationId(data.id);
      return data;
    },
  });

  const addStoreMutation = useMutation({
    mutationFn: async (data: {
      name: string;
      domain: string;
      accessToken: string;
      parentStoreId?: number;
      isBranch?: boolean;
      syncInventory?: boolean;
    }) => {
      const endpoint = data.parentStoreId
        ? `/api/stores/${data.parentStoreId}/branches`
        : "/api/stores";
      const res = await apiRequest("POST", endpoint, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/stores"] });
      toast({
        title: "Store added successfully",
        description: "You can now use this store in migrations",
      });
    },
  });

  const syncInventoryMutation = useMutation({
    mutationFn: async (storeId: number) => {
      const res = await apiRequest("POST", `/api/stores/${storeId}/sync-inventory`);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Inventory sync completed",
        description: "Store inventory has been updated",
      });
    },
  });

  return (
    <div className="min-h-screen bg-[#f4f6f8] p-8">
      <div className="max-w-4xl mx-auto">
        <Tabs defaultValue="connect">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="connect">Connect Stores</TabsTrigger>
            <TabsTrigger value="branch">Branch Stores</TabsTrigger>
            <TabsTrigger value="migrate">Migrate Data</TabsTrigger>
          </TabsList>

          <TabsContent value="connect" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Add Shopify Store</CardTitle>
              </CardHeader>
              <CardContent>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    const formData = new FormData(e.currentTarget);
                    addStoreMutation.mutate({
                      name: formData.get("name") as string,
                      domain: formData.get("domain") as string,
                      accessToken: formData.get("accessToken") as string,
                    });
                  }}
                  className="space-y-4"
                >
                  <div>
                    <Label htmlFor="name">Store Name</Label>
                    <Input id="name" name="name" required />
                  </div>
                  <div>
                    <Label htmlFor="domain">Store Domain</Label>
                    <Input id="domain" name="domain" required placeholder="your-store.myshopify.com" />
                  </div>
                  <div>
                    <Label htmlFor="accessToken">Access Token</Label>
                    <Input id="accessToken" name="accessToken" type="password" required />
                  </div>
                  <Button type="submit" className="w-full bg-[#008060] hover:bg-[#006e52]">
                    Add Store
                  </Button>
                </form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="branch" className="mt-6 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Create Branch Store</CardTitle>
              </CardHeader>
              <CardContent>
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    const formData = new FormData(e.currentTarget);
                    if (!selectedParentStore) return;

                    addStoreMutation.mutate({
                      name: formData.get("name") as string,
                      domain: formData.get("domain") as string,
                      accessToken: formData.get("accessToken") as string,
                      parentStoreId: selectedParentStore,
                      isBranch: true,
                      syncInventory: formData.get("syncInventory") === "on",
                    });
                  }}
                  className="space-y-4"
                >
                  <div>
                    <Label>Parent Store</Label>
                    <select
                      className="w-full p-2 border rounded"
                      value={selectedParentStore}
                      onChange={(e) => setSelectedParentStore(Number(e.target.value))}
                      required
                    >
                      <option value="">Select parent store</option>
                      {stores?.filter(s => !s.isBranch).map((store) => (
                        <option key={store.id} value={store.id}>
                          {store.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <Label htmlFor="name">Branch Store Name</Label>
                    <Input id="name" name="name" required />
                  </div>
                  <div>
                    <Label htmlFor="domain">Branch Store Domain</Label>
                    <Input id="domain" name="domain" required placeholder="branch-store.myshopify.com" />
                  </div>
                  <div>
                    <Label htmlFor="accessToken">Branch Store Access Token</Label>
                    <Input id="accessToken" name="accessToken" type="password" required />
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch id="syncInventory" name="syncInventory" />
                    <Label htmlFor="syncInventory">Sync inventory with parent store</Label>
                  </div>
                  <Button type="submit" className="w-full bg-[#008060] hover:bg-[#006e52]">
                    <GitBranch className="mr-2 h-4 w-4" />
                    Create Branch Store
                  </Button>
                </form>
              </CardContent>
            </Card>

            {selectedParentStore && branchStores && branchStores.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Branch Stores</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {branchStores.map((store) => (
                      <div key={store.id} className="flex items-center justify-between p-4 border rounded">
                        <div>
                          <h3 className="font-medium">{store.name}</h3>
                          <p className="text-sm text-gray-500">{store.domain}</p>
                        </div>
                        <Button
                          variant="outline"
                          onClick={() => syncInventoryMutation.mutate(store.id)}
                          disabled={!store.syncInventory}
                        >
                          <RefreshCw className="mr-2 h-4 w-4" />
                          Sync Inventory
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="migrate" className="mt-6 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Select Stores</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>Source Store</Label>
                  <select
                    className="w-full p-2 border rounded"
                    value={selectedSource}
                    onChange={(e) => setSelectedSource(Number(e.target.value))}
                  >
                    <option value="">Select source store</option>
                    {stores?.map((store) => (
                      <option key={store.id} value={store.id}>
                        {store.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <Label>Destination Store</Label>
                  <select
                    className="w-full p-2 border rounded"
                    value={selectedDest}
                    onChange={(e) => setSelectedDest(Number(e.target.value))}
                  >
                    <option value="">Select destination store</option>
                    {stores?.map((store) => (
                      <option key={store.id} value={store.id}>
                        {store.name}
                      </option>
                    ))}
                  </select>
                </div>
                <Button
                  onClick={() => createMigrationMutation.mutate()}
                  disabled={!selectedSource || !selectedDest}
                  className="w-full bg-[#008060] hover:bg-[#006e52]"
                >
                  <ArrowLeftRight className="mr-2 h-4 w-4" />
                  Start Migration
                </Button>
              </CardContent>
            </Card>

            {migration && (
              <Card>
                <CardHeader>
                  <CardTitle>Migration Progress</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span>Status: {migration.status}</span>
                      {migration.status === "completed" && (
                        <Check className="h-5 w-5 text-green-500" />
                      )}
                      {migration.status === "failed" && (
                        <XCircle className="h-5 w-5 text-red-500" />
                      )}
                    </div>
                    <Progress value={migration.progress} />
                    <div className="text-sm text-gray-600">
                      Products: {migration.productCount}
                      <br />
                      Collections: {migration.collectionCount}
                    </div>
                    {migration.error && (
                      <div className="text-sm text-red-500">{migration.error}</div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
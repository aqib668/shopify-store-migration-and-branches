import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Store, Migration } from "@shared/schema";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from "recharts";

export default function StatsPage() {
  const { data: stores } = useQuery<Store[]>({
    queryKey: ["/api/stores"],
  });

  const { data: migrations } = useQuery<Migration[]>({
    queryKey: ["/api/migrations"],
  });

  const primaryStores = stores?.filter(s => !s.isBranch) || [];
  const branchStores = stores?.filter(s => s.isBranch) || [];
  const completedMigrations = migrations?.filter(m => m.status === "completed") || [];

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Statistics</h1>

      <div className="grid md:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle>Total Stores</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{stores?.length || 0}</div>
            <p className="text-sm text-muted-foreground">
              Primary: {primaryStores.length} | Branch: {branchStores.length}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Migrations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {completedMigrations.length}
            </div>
            <p className="text-sm text-muted-foreground">
              Successfully completed migrations
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Products</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {completedMigrations.reduce((sum, m) => sum + (m.productCount || 0), 0)}
            </div>
            <p className="text-sm text-muted-foreground">
              Total products migrated
            </p>
          </CardContent>
        </Card>
      </div>

      {migrations && migrations.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Migration History</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="w-full overflow-x-auto">
              <BarChart
                width={800}
                height={300}
                data={migrations}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="id" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="productCount" fill="#008060" name="Products" />
              </BarChart>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

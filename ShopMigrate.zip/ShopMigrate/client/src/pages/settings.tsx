import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";

export default function SettingsPage() {
  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Settings</h1>

      <Card>
        <CardHeader>
          <CardTitle>Notifications</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center space-x-2">
            <Switch id="migration-notifications" />
            <Label htmlFor="migration-notifications">
              Email notifications for migration status
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <Switch id="inventory-notifications" />
            <Label htmlFor="inventory-notifications">
              Email notifications for inventory sync
            </Label>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Default Migration Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center space-x-2">
            <Switch id="skip-images" />
            <Label htmlFor="skip-images">
              Skip product images during migration
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <Switch id="preserve-ids" />
            <Label htmlFor="preserve-ids">
              Preserve product IDs when possible
            </Label>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Branch Store Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center space-x-2">
            <Switch id="auto-sync" />
            <Label htmlFor="auto-sync">
              Enable automatic inventory sync
            </Label>
          </div>
          <div className="flex items-center space-x-2">
            <Switch id="sync-notifications" />
            <Label htmlFor="sync-notifications">
              Notify on inventory sync failures
            </Label>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

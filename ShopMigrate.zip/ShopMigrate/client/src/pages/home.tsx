import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Store, Migration } from "@shared/schema";
import { ArrowRight, GitBranch, BarChart2, Settings, ArrowLeftRight } from "lucide-react";
import { SiShopify } from "react-icons/si";

export default function Home() {
  const { data: stores } = useQuery<Store[]>({
    queryKey: ["/api/stores"],
  });

  const { data: migrations } = useQuery<Migration[]>({
    queryKey: ["/api/migrations"],
  });

  const primaryStores = stores?.filter(s => !s.isBranch) || [];
  const branchStores = stores?.filter(s => s.isBranch) || [];
  const completedMigrations = migrations?.filter(m => m.status === "completed") || [];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center">
          <SiShopify className="h-10 w-10 text-[#008060] mr-4" />
          <h1 className="text-3xl font-bold text-[#212b36]">Dashboard</h1>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Primary Stores</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{primaryStores.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Branch Stores</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{branchStores.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Migrations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{completedMigrations.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Products Migrated</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {completedMigrations.reduce((sum, m) => sum + (m.productCount || 0), 0)}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Primary Stores</CardTitle>
            <CardDescription>Manage your connected Shopify stores</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {primaryStores.length === 0 ? (
              <p className="text-muted-foreground">No stores connected yet</p>
            ) : (
              primaryStores.map((store) => (
                <div key={store.id} className="flex items-center justify-between p-4 border rounded">
                  <div>
                    <h3 className="font-medium">{store.name}</h3>
                    <p className="text-sm text-muted-foreground">{store.domain}</p>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {branchStores.filter(b => b.parentStoreId === store.id).length} branches
                  </div>
                </div>
              ))
            )}
            <Link href="/branches">
              <Button className="w-full bg-[#008060] hover:bg-[#006e52]">
                <GitBranch className="mr-2 h-4 w-4" />
                Manage Stores
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Migrations</CardTitle>
            <CardDescription>Latest data migration activities</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {!migrations || migrations.length === 0 ? (
              <p className="text-muted-foreground">No migrations performed yet</p>
            ) : (
              migrations.slice(0, 3).map((migration) => (
                <div key={migration.id} className="flex items-center justify-between p-4 border rounded">
                  <div>
                    <h3 className="font-medium">Migration #{migration.id}</h3>
                    <p className="text-sm text-muted-foreground">
                      {migration.productCount} products, {migration.collectionCount} collections
                    </p>
                  </div>
                  <div className={`text-sm ${
                    migration.status === "completed" ? "text-green-500" : 
                    migration.status === "failed" ? "text-red-500" : 
                    "text-blue-500"
                  }`}>
                    {migration.status}
                  </div>
                </div>
              ))
            )}
            <Button className="w-full" variant="outline" asChild>
              <Link href="/stats">
                <BarChart2 className="mr-2 h-4 w-4" />
                View All Stats
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Quick Links */}
      <div className="grid md:grid-cols-3 gap-4">
        <Link href="/branches">
          <Card className="hover:bg-accent cursor-pointer transition-colors">
            <CardHeader>
              <GitBranch className="h-8 w-8 text-[#008060] mb-2" />
              <CardTitle>Branch Stores</CardTitle>
              <CardDescription>Manage your branch stores and sync inventory</CardDescription>
            </CardHeader>
          </Card>
        </Link>

        <Link href="/stats">
          <Card className="hover:bg-accent cursor-pointer transition-colors">
            <CardHeader>
              <BarChart2 className="h-8 w-8 text-[#008060] mb-2" />
              <CardTitle>Statistics</CardTitle>
              <CardDescription>View detailed migration and sync statistics</CardDescription>
            </CardHeader>
          </Card>
        </Link>

        <Link href="/settings">
          <Card className="hover:bg-accent cursor-pointer transition-colors">
            <CardHeader>
              <Settings className="h-8 w-8 text-[#008060] mb-2" />
              <CardTitle>Settings</CardTitle>
              <CardDescription>Configure app settings and notifications</CardDescription>
            </CardHeader>
          </Card>
        </Link>
      </div>
    </div>
  );
}
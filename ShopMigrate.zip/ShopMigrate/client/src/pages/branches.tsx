import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Store } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { GitBranch, RefreshCw } from "lucide-react";
import { Switch } from "@/components/ui/switch";

export default function BranchesPage() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [selectedParentStore, setSelectedParentStore] = useState<number>();

  const { data: stores } = useQuery<Store[]>({
    queryKey: ["/api/stores"],
  });

  const { data: branchStores } = useQuery<Store[]>({
    queryKey: ["/api/stores", selectedParentStore, "branches"],
    enabled: !!selectedParentStore,
  });

  const addBranchMutation = useMutation({
    mutationFn: async (data: {
      name: string;
      domain: string;
      accessToken: string;
      parentStoreId: number;
      syncInventory: boolean;
    }) => {
      const res = await apiRequest(
        "POST",
        `/api/stores/${data.parentStoreId}/branches`,
        {
          name: data.name,
          domain: data.domain,
          accessToken: data.accessToken,
          isBranch: true,
          syncInventory: data.syncInventory,
        }
      );
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/stores"] });
      toast({
        title: "Branch store added",
        description: "Branch store has been connected successfully",
      });
    },
  });

  const syncInventoryMutation = useMutation({
    mutationFn: async (storeId: number) => {
      const res = await apiRequest("POST", `/api/stores/${storeId}/sync-inventory`);
      return res.json();
    },
    onSuccess: () => {
      toast({
        title: "Inventory sync completed",
        description: "Branch store inventory has been updated",
      });
    },
  });

  return (
    <div className="space-y-8">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Branch Stores</h1>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Add Branch Store</CardTitle>
          </CardHeader>
          <CardContent>
            <form
              onSubmit={(e) => {
                e.preventDefault();
                const formData = new FormData(e.currentTarget);
                if (!selectedParentStore) return;

                addBranchMutation.mutate({
                  name: formData.get("name") as string,
                  domain: formData.get("domain") as string,
                  accessToken: formData.get("accessToken") as string,
                  parentStoreId: selectedParentStore,
                  syncInventory: formData.get("syncInventory") === "on",
                });
              }}
              className="space-y-4"
            >
              <div>
                <Label>Primary Store</Label>
                <select
                  className="w-full p-2 border rounded"
                  value={selectedParentStore}
                  onChange={(e) => setSelectedParentStore(Number(e.target.value))}
                  required
                >
                  <option value="">Select primary store</option>
                  {stores?.filter(s => !s.isBranch).map((store) => (
                    <option key={store.id} value={store.id}>
                      {store.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <Label htmlFor="name">Branch Store Name</Label>
                <Input id="name" name="name" required />
              </div>
              <div>
                <Label htmlFor="domain">Branch Store Domain</Label>
                <Input
                  id="domain"
                  name="domain"
                  required
                  placeholder="branch-store.myshopify.com"
                />
              </div>
              <div>
                <Label htmlFor="accessToken">Access Token</Label>
                <Input id="accessToken" name="accessToken" type="password" required />
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="syncInventory" name="syncInventory" />
                <Label htmlFor="syncInventory">
                  Sync inventory with primary store
                </Label>
              </div>
              <Button type="submit" className="w-full bg-[#008060] hover:bg-[#006e52]">
                <GitBranch className="mr-2 h-4 w-4" />
                Add Branch Store
              </Button>
            </form>
          </CardContent>
        </Card>

        {selectedParentStore && branchStores && (
          <Card>
            <CardHeader>
              <CardTitle>Connected Branch Stores</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {branchStores.length === 0 ? (
                  <p className="text-muted-foreground">No branch stores connected yet</p>
                ) : (
                  branchStores.map((store) => (
                    <div
                      key={store.id}
                      className="flex items-center justify-between p-4 border rounded"
                    >
                      <div>
                        <h3 className="font-medium">{store.name}</h3>
                        <p className="text-sm text-gray-500">{store.domain}</p>
                      </div>
                      <Button
                        variant="outline"
                        onClick={() => syncInventoryMutation.mutate(store.id)}
                        disabled={!store.syncInventory}
                      >
                        <RefreshCw className="mr-2 h-4 w-4" />
                        Sync Inventory
                      </Button>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

import { useEffect } from "react";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { SiShopify } from "react-icons/si";

export default function Install() {
  const [, setLocation] = useLocation();

  const handleInstall = async () => {
    const shop = (document.getElementById("shop") as HTMLInputElement).value;
    if (!shop) return;
    
    try {
      const res = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ shop }),
      });
      
      if (!res.ok) throw new Error("Failed to start installation");
      
      const { authUrl } = await res.json();
      window.location.href = authUrl;
    } catch (error) {
      console.error("Installation error:", error);
    }
  };

  // Handle OAuth callback
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const shop = params.get("shop");
    const code = params.get("code");
    
    if (shop && code) {
      fetch("/api/auth/callback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ shop, code }),
      })
        .then((res) => res.json())
        .then(() => setLocation("/"))
        .catch(console.error);
    }
  }, [setLocation]);

  return (
    <div className="min-h-screen bg-[#f4f6f8] flex items-center justify-center">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <SiShopify className="h-12 w-12 text-[#008060] mx-auto mb-4" />
          <CardTitle>Install Migration App</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div>
              <input
                id="shop"
                type="text"
                placeholder="your-store.myshopify.com"
                className="w-full p-2 border rounded"
              />
            </div>
            <Button
              onClick={handleInstall}
              className="w-full bg-[#008060] hover:bg-[#006e52]"
            >
              Install App
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
